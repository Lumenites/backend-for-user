import Notification from "../models/Notification.js";

export const createNotification = async (req, res) => {
  res.json(await new Notification(req.body).save());
};

export const getNotifications = async (req, res) => {
  res.json(await Notification.find({ userId: req.params.userId }).sort({ date: -1 }));
};
