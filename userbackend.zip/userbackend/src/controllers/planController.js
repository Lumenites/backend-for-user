import Plan from "../models/Plan.js";

export const getPlans = async (req, res) => res.json(await Plan.find());
export const createPlan = async (req, res) => res.json(await new Plan(req.body).save());
