import Subscription from "../models/Subscription.js";
import Plan from "../models/Plan.js";

export const subscribe = async (req, res) => {
  const { userId, planId, months = 1 } = req.body;
  const plan = await Plan.findById(planId);
  if (!plan) return res.status(404).json({ message: "Plan not found" });

  const start = new Date();
  const end = new Date();
  end.setMonth(end.getMonth() + months);

  const sub = await new Subscription({ userId, planId, startDate: start, endDate: end }).save();
  res.json(await sub.populate("planId"));
};

export const getHistory = async (req, res) => {
  res.json(await Subscription.find({ userId: req.params.userId }).populate("planId"));
};
