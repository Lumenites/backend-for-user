import mongoose from "mongoose";

const planSchema = new mongoose.Schema({
  code: { type: String, unique: true, required: true },
  name: { type: String, required: true },
  price: { type: Number, required: true },
  quota: { type: String },
  description: { type: String },
});

const Plan = mongoose.model("Plan", planSchema);

export default Plan;
