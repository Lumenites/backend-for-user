import dotenv from "dotenv";
import mongoose from "mongoose";
import Plan from "../models/Plan.js";

dotenv.config();

const plans = [
  {
    code: "BASIC50",
    name: "Basic 50 Mbps",
    price: 499,
    quota: "300GB",
    description: "Budget-friendly plan with decent speed.",
  },
  {
    code: "PRO100",
    name: "Pro 100 Mbps",
    price: 999,
    quota: "1TB",
    description: "High-speed plan for professionals and streamers.",
  },
  {
    code: "ULTRA200",
    name: "Ultra 200 Mbps",
    price: 1499,
    quota: "2TB",
    description: "Ultra-fast plan for heavy internet users.",
  },
  {
    code: "FAMILY75",
    name: "Family 75 Mbps",
    price: 799,
    quota: "500GB",
    description: "Affordable plan for families with multiple users.",
  },
  {
    code: "STUDENT30",
    name: "Student 30 Mbps",
    price: 299,
    quota: "100GB",
    description: "Low-cost plan tailored for students.",
  },
];

const seedPlans = async () => {
  try {
    await mongoose.connect(process.env.MONGO_URI);
    console.log(" MongoDB connected");

    await Plan.deleteMany({});
    console.log(" Old plans removed");

    await Plan.insertMany(plans, { ordered: true });
    console.log(" ✅ Plans seeded successfully");

    process.exit();
  } catch (err) {
    console.error(" Seeding error:", err);
    if (err.errors) {
      for (let [key, val] of Object.entries(err.errors)) {
        console.error(`${key}: ${val.message}`);
      }
    }
    if (err.cause) {
      console.error("Cause:", err.cause);
    }
    process.exit(1);
  }
};

seedPlans();
