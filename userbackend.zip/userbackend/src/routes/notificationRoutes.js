import express from "express";
import { createNotification, getNotifications } from "../controllers/notificationController.js";
import { protect, adminOnly } from "../middlewares/authMiddleware.js";

const router = express.Router();
router.post("/", protect, adminOnly, createNotification);
router.get("/:userId", protect, getNotifications);
export default router;
