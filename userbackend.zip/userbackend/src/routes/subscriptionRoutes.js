import express from "express";
import { subscribe, getHistory } from "../controllers/subscriptionController.js";
import { protect } from "../middlewares/authMiddleware.js";

const router = express.Router();
router.post("/", protect, subscribe);
router.get("/:userId/history", protect, getHistory);
export default router;
