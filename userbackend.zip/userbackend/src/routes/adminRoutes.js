import express from "express";
import { protect, adminOnly } from "../middlewares/authMiddleware.js";

const router = express.Router();
router.get("/summary", protect, adminOnly, (req, res) => res.json({ msg: "Admin summary placeholder" }));
export default router;
